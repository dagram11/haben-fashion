import { CategoryPage } from '@/components/category-page'

export default function LowerBodyPage() {
  return (
    <CategoryPage
      clothType="Trousers"
      title="Trousers"
      description="Explore our selection of trousers. See how they look on you with virtual try-on."
    />
  )
}
