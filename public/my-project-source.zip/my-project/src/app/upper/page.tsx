import { CategoryPage } from '@/components/category-page'

export default function UpperBodyPage() {
  return (
    <CategoryPage
      clothType="Hoodies"
      title="Hoodies"
      description="Discover our collection of hoodies. Try them on virtually before you buy."
    />
  )
}
