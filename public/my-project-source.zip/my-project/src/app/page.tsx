'use client'

import { useState, useEffect } from 'react'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { ProductCard } from '@/components/product-card'
import { ProductDetailModal } from '@/components/product-detail-modal'
import { CartDrawer } from '@/components/cart-drawer'
import { CheckoutModal } from '@/components/checkout-modal'
import { TryOnModal } from '@/components/try-on-modal'
import { ArrowRight, Sparkles, Truck, Shield, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface Product {
  id: string
  name: string
  description: string
  category: string
  cloth_type: string
  price: number
  image_1: string
  image_2?: string
  image_3?: string
  sizes: string[]
  colors: string[]
  featured?: boolean
  stock?: number
}

export default function HomePage() {
  const [products, setProducts] = useState<Product[]>([])
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([])
  const [clothType, setClothType] = useState('all')
  const [isLoading, setIsLoading] = useState(true)
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [isProductModalOpen, setIsProductModalOpen] = useState(false)
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false)
  
  // Try-on modal state
  const [isTryOnModalOpen, setIsTryOnModalOpen] = useState(false)
  const [tryOnProduct, setTryOnProduct] = useState<Product | null>(null)

  // Check if checkout param is in URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    if (params.get('checkout') === 'true') {
      setIsCheckoutOpen(true)
    }
  }, [])

  // Fetch products
  useEffect(() => {
    const fetchProducts = async () => {
      setIsLoading(true)
      try {
        const clothTypeParam = clothType !== 'all' ? `&cloth_type=${clothType}` : ''
        const [allRes, featuredRes] = await Promise.all([
          fetch(`/api/products?category=all${clothTypeParam}`),
          fetch('/api/products?featured=true'),
        ])
        const allData = await allRes.json()
        const featuredData = await featuredRes.json()
        setProducts(allData)
        setFeaturedProducts(featuredData)
      } catch (error) {
        console.error('Failed to fetch products:', error)
      } finally {
        setIsLoading(false)
      }
    }
    fetchProducts()
  }, [clothType])

  const handleViewDetails = (product: Product) => {
    setSelectedProduct(product)
    setIsProductModalOpen(true)
  }

  const handleOpenTryOn = (product: Product) => {
    setTryOnProduct(product)
    setIsTryOnModalOpen(true)
    setIsProductModalOpen(false)
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-white flex flex-col">
      <Header
        currentCategory={clothType}
        onCategoryChange={setClothType}
      />
      
      <main className="flex-1 pt-20">
        {/* Hero Section */}
        <section className="relative min-h-[90vh] flex items-center">
          {/* Background */}
          <div className="absolute inset-0 z-0">
            <div className="absolute inset-0 bg-gradient-to-b from-zinc-900/50 via-zinc-900/80 to-zinc-950" />
            <img
              src="https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=1920&q=80"
              alt="Fashion hero"
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
            <div className="max-w-2xl">
              <div className="flex items-center gap-2 mb-6">
                <Sparkles className="w-5 h-5 text-white" />
                <span className="text-sm uppercase tracking-widest">Virtual Try-On</span>
              </div>
              <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold leading-tight mb-6">
                Try Before
                <br />
                You Buy
              </h1>
              <p className="text-lg sm:text-xl text-zinc-300 mb-8 max-w-lg">
                Experience fashion like never before. See how clothes look on you with our AI-powered virtual try-on technology.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button
                  onClick={() => setClothType('all')}
                  className="rounded-xl bg-white text-black hover:bg-zinc-200 px-8 py-6 text-lg"
                >
                  Shop Now
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
                <Button
                  variant="outline"
                  className="rounded-xl border-white/30 hover:bg-white/10 px-8 py-6 text-lg"
                >
                  Learn More
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="py-20 border-y border-zinc-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 rounded-2xl bg-zinc-800 flex items-center justify-center mx-auto mb-4">
                  <Truck className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Free Shipping</h3>
                <p className="text-zinc-400">On all orders over $150</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 rounded-2xl bg-zinc-800 flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Secure Payment</h3>
                <p className="text-zinc-400">100% secure transactions</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 rounded-2xl bg-zinc-800 flex items-center justify-center mx-auto mb-4">
                  <RefreshCw className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Easy Returns</h3>
                <p className="text-zinc-400">30-day return policy</p>
              </div>
            </div>
          </div>
        </section>

        {/* Featured Products */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-12">
              <div>
                <h2 className="text-3xl font-bold">Featured Collection</h2>
                <p className="text-zinc-400 mt-2">Handpicked styles for you</p>
              </div>
              <Button
                variant="outline"
                onClick={() => setClothType('all')}
                className="rounded-xl hidden sm:flex"
              >
                View All
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>

            {isLoading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="space-y-4">
                    <div className="aspect-[3/4] bg-zinc-800 rounded-2xl animate-pulse" />
                    <div className="h-4 bg-zinc-800 rounded animate-pulse w-3/4" />
                    <div className="h-4 bg-zinc-800 rounded animate-pulse w-1/2" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {featuredProducts.slice(0, 4).map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onViewDetails={handleViewDetails}
                  />
                ))}
              </div>
            )}
          </div>
        </section>

        {/* All Products */}
        <section className="py-20 bg-zinc-900/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-12">
              <h2 className="text-3xl font-bold">
                {clothType === 'all' ? 'All Products' : clothType}
              </h2>
              <p className="text-zinc-400 mt-2">
                {products.length} {products.length === 1 ? 'item' : 'items'}
              </p>
            </div>

            {isLoading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="space-y-4">
                    <div className="aspect-[3/4] bg-zinc-800 rounded-2xl animate-pulse" />
                    <div className="h-4 bg-zinc-800 rounded animate-pulse w-3/4" />
                    <div className="h-4 bg-zinc-800 rounded animate-pulse w-1/2" />
                  </div>
                ))}
              </div>
            ) : products.length === 0 ? (
              <div className="text-center py-20">
                <p className="text-zinc-400 text-lg">No products found in this category</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {products.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onViewDetails={handleViewDetails}
                  />
                ))}
              </div>
            )}
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-gradient-to-r from-zinc-800 to-zinc-900 rounded-3xl p-12 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(255,255,255,0.05),transparent)]" />
              <div className="relative">
                <h2 className="text-3xl sm:text-4xl font-bold mb-4">
                  Experience Virtual Try-On
                </h2>
                <p className="text-zinc-400 max-w-2xl mx-auto mb-8">
                  See how any outfit looks on you before making a purchase. 
                  Our AI technology creates realistic try-on previews instantly.
                </p>
                <Button
                  onClick={() => {
                    if (featuredProducts.length > 0) {
                      handleViewDetails(featuredProducts[0])
                    }
                  }}
                  className="rounded-xl bg-white text-black hover:bg-zinc-200 px-8 py-6 text-lg"
                >
                  Try It Now
                  <Sparkles className="w-5 h-5 ml-2" />
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />

      {/* Modals */}
      <CartDrawer />
      <ProductDetailModal
        product={selectedProduct}
        isOpen={isProductModalOpen}
        onClose={() => setIsProductModalOpen(false)}
        onTryOn={handleOpenTryOn}
      />
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
      />
      
      {/* Try-On Modal */}
      {isTryOnModalOpen && tryOnProduct && (
        <TryOnModal
          productId={tryOnProduct.id}
          productName={tryOnProduct.name}
          productImage={tryOnProduct.image_3 || tryOnProduct.image_1}
          productDescription={tryOnProduct.description}
          productCategory={tryOnProduct.category}
          sizes={tryOnProduct.sizes}
          onClose={() => {
            setIsTryOnModalOpen(false)
            setTryOnProduct(null)
          }}
        />
      )}
    </div>
  )
}
