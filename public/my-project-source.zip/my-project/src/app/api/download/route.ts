import { NextRequest, NextResponse } from 'next/server'
import sharp from 'sharp'
import { readFile } from 'fs/promises'
import path from 'path'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { tryonId, productName, imageBase64 } = body

    if (!tryonId) {
      return NextResponse.json(
        { error: 'Missing tryonId' },
        { status: 400 }
      )
    }

    if (!imageBase64) {
      return NextResponse.json(
        { error: 'Missing image data. Please regenerate the try-on.' },
        { status: 400 }
      )
    }

    let watermarkedImage: Buffer

    try {
      // Convert base64 to buffer
      const cleanBuffer = Buffer.from(imageBase64, 'base64')

      // Read the watermark logo from local assets
      const watermarkPath = path.join(process.cwd(), 'public', 'assets', 'watermark-logo.png')
      let watermarkBuffer: Buffer
      
      try {
        watermarkBuffer = await readFile(watermarkPath)
        console.log('Watermark loaded, size:', watermarkBuffer.length, 'bytes')
      } catch (fileError) {
        console.error('Watermark file not found, using fallback:', fileError)
        watermarkBuffer = await createFallbackWatermark()
      }

      // Get the main image dimensions
      const mainImageMeta = await sharp(cleanBuffer).metadata()
      const mainWidth = mainImageMeta.width || 800
      console.log('Main image dimensions:', mainWidth, 'x', mainImageMeta.height)

      // Resize watermark to appropriate size (proportional to image width)
      const watermarkWidth = Math.round(Math.min(220, mainWidth * 0.22))
      console.log('Watermark target width:', watermarkWidth)
      
      const resizedWatermark = await sharp(watermarkBuffer)
        .resize(watermarkWidth, null, { 
          fit: 'inside',
        })
        .png()
        .toBuffer()

      // Get resized watermark dimensions
      const watermarkMeta = await sharp(resizedWatermark).metadata()
      const watermarkWidthFinal = watermarkMeta.width || 100
      console.log('Resized watermark dimensions:', watermarkWidthFinal, 'x', watermarkMeta.height)

      // Calculate position for top-right corner with padding
      const padding = 20
      const xPosition = mainWidth - watermarkWidthFinal - padding
      const yPosition = padding
      console.log('Watermark position: top=', yPosition, 'left=', xPosition)

      // Apply watermark to the top-right corner
      watermarkedImage = await sharp(cleanBuffer)
        .composite([
          {
            input: resizedWatermark,
            top: yPosition,
            left: xPosition,
          },
        ])
        .png()
        .toBuffer()
    } catch (imageError) {
      console.error('Image processing error:', imageError)
      // Return original image if watermarking fails
      watermarkedImage = Buffer.from(imageBase64, 'base64')
    }

    // Create safe filename
    const safeFileName = (productName || 'tryon-result')
      .replace(/[^a-z0-9]/gi, '-')
      .replace(/-+/g, '-')
      .toLowerCase()

    // Return the watermarked image
    return new NextResponse(watermarkedImage, {
      status: 200,
      headers: {
        'Content-Type': 'image/png',
        'Content-Disposition': `attachment; filename="${safeFileName}.png"`,
        'Content-Length': watermarkedImage.length.toString(),
      },
    })
  } catch (error) {
    console.error('Download error:', error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to process download' },
      { status: 500 }
    )
  }
}

// Helper function to create fallback watermark
async function createFallbackWatermark(): Promise<Buffer> {
  const watermarkSvg = `
    <svg width="120" height="40" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:rgba(0,0,0,0.7)"/>
          <stop offset="100%" style="stop-color:rgba(30,30,30,0.7)"/>
        </linearGradient>
      </defs>
      <rect width="100%" height="100%" fill="url(#bg)" rx="8"/>
      <text x="50%" y="50%" font-family="Arial, sans-serif" font-size="18" font-weight="bold" fill="white" text-anchor="middle" dominant-baseline="middle">VTON</text>
    </svg>
  `
  return Buffer.from(watermarkSvg)
}
