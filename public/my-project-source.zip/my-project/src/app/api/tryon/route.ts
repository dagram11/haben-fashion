import { NextRequest, NextResponse } from 'next/server'
import Replicate from 'replicate'

// Initialize Replicate with the API token
const getReplicate = () => {
  const token = process.env.REPLICATE_API_TOKEN
  if (!token) {
    throw new Error('REPLICATE_API_TOKEN is not configured')
  }
  return new Replicate({ auth: token })
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { productId, userImage, size, ip, country, city, productImage, productDescription, productCategory } = body

    // Validate required fields
    if (!productId || !userImage || !size) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Map category to Replicate format
    const categoryMap: Record<string, string> = {
      upper_body: 'upper_body',
      lower_body: 'lower_body',
      dresses: 'dresses',
    }

    const category = categoryMap[productCategory] || 'upper_body'

    // Initialize Replicate
    const replicate = getReplicate()

    // Run Replicate model
    const input = {
      garm_img: productImage,
      human_img: userImage,
      garment_des: productDescription || 'Fashion item',
      category: category,
      crop: true,
      steps: 30,
    }

    console.log('Calling Replicate with input:', { ...input, human_img: '[IMAGE]', garm_img: '[IMAGE]' })

    const output = await replicate.run(
      'cuuupid/idm-vton:0513734a452173b8173e907e3a59d19a36266e55b48528559432bd21c7d7e985',
      { input }
    )

    // Get the output URL
    const outputUrl = (output as { url: () => string }).url()
    console.log('Replicate output URL:', outputUrl)

    // Convert the output image to base64
    const imageResponse = await fetch(outputUrl)
    const arrayBuffer = await imageResponse.arrayBuffer()
    const base64Image = Buffer.from(arrayBuffer).toString('base64')

    // Generate a mock try-on ID for tracking
    const tryonId = `tryon-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`

    return NextResponse.json({
      success: true,
      tryonId: tryonId,
      preview: base64Image,
    })
  } catch (error) {
    console.error('Try-on error:', error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to generate try-on' },
      { status: 500 }
    )
  }
}
