import { NextRequest, NextResponse } from 'next/server'

// Mock products data for when Supabase is not configured
const mockProducts = [
  {
    id: '1',
    name: 'Classic Black Blazer',
    description: 'Elegant tailored blazer with a modern slim fit. Perfect for both formal and smart casual occasions. Features premium wool blend fabric with subtle texture.',
    category: 'upper_body',
    cloth_type: 'Hoodies',
    price: 299.00,
    image_1: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=800&q=80',
    image_2: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=800&q=80',
    image_3: 'https://images.unsplash.com/photo-1592878904946-b3cd8ae243d0?w=800&q=80',
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Black', 'Charcoal', 'Navy'],
    featured: true,
    stock: 50,
  },
  {
    id: '2',
    name: 'Silk Evening Top',
    description: 'Luxurious silk evening top with delicate draping. Features a subtle sheen and elegant cowl neckline. Perfect for special occasions.',
    category: 'upper_body',
    cloth_type: 'Hoodies',
    price: 189.00,
    image_1: 'https://images.unsplash.com/photo-1485968579580-b6d095142e6e?w=800&q=80',
    image_2: 'https://images.unsplash.com/photo-1485968579580-b6d095142e6e?w=800&q=80',
    image_3: null,
    sizes: ['XS', 'S', 'M', 'L'],
    colors: ['Champagne', 'Rose', 'Black'],
    featured: true,
    stock: 30,
  },
  {
    id: '3',
    name: 'Cashmere Sweater',
    description: 'Ultra-soft pure cashmere sweater with relaxed fit. Features ribbed cuffs and hem for a refined finish. A timeless wardrobe essential.',
    category: 'upper_body',
    cloth_type: 'Hoodies',
    price: 249.00,
    image_1: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=800&q=80',
    image_2: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=800&q=80',
    image_3: 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=800&q=80',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Cream', 'Grey', 'Camel', 'Black'],
    featured: true,
    stock: 40,
  },
  {
    id: '4',
    name: 'Structured White Shirt',
    description: 'Crisp white cotton shirt with structured collar and French cuffs. Features hidden button placket for a clean, modern look.',
    category: 'upper_body',
    cloth_type: 'Hoodies',
    price: 159.00,
    image_1: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=800&q=80',
    image_2: 'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?w=800&q=80',
    image_3: 'https://images.unsplash.com/photo-1598032895397-b947c9c3bb4b?w=800&q=80',
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: ['White', 'Light Blue'],
    featured: false,
    stock: 60,
  },
  {
    id: '5',
    name: 'Leather Biker Jacket',
    description: 'Premium lambskin leather biker jacket with asymmetric zip. Features quilted shoulder panels and adjustable belt. A statement piece.',
    category: 'upper_body',
    cloth_type: 'Hoodies',
    price: 599.00,
    image_1: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&q=80',
    image_2: 'https://images.unsplash.com/photo-1520975954732-35dd22299614?w=800&q=80',
    image_3: 'https://images.unsplash.com/photo-1521223890158-f9f7c3d5d504?w=800&q=80',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Black', 'Brown'],
    featured: true,
    stock: 25,
  },
  {
    id: '6',
    name: 'Tailored Wool Trousers',
    description: 'Expertly tailored wool trousers with a slim fit. Features pressed creases and extended waistband tab for a polished look.',
    category: 'lower_body',
    cloth_type: 'Trousers',
    price: 199.00,
    image_1: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=800&q=80',
    image_2: 'https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=800&q=80',
    image_3: 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=800&q=80',
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Black', 'Charcoal', 'Navy'],
    featured: true,
    stock: 45,
  },
  {
    id: '7',
    name: 'High-Waist Palazzo Pants',
    description: 'Flowing high-waist palazzo pants in premium crepe fabric. Features wide legs and concealed side zip. Elegant and comfortable.',
    category: 'lower_body',
    cloth_type: 'Trousers',
    price: 169.00,
    image_1: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=800&q=80',
    image_2: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=800&q=80',
    image_3: 'https://images.unsplash.com/photo-1551854838-212c50b4c184?w=800&q=80',
    sizes: ['XS', 'S', 'M', 'L'],
    colors: ['Black', 'Cream', 'Burgundy'],
    featured: false,
    stock: 35,
  },
  {
    id: '8',
    name: 'Slim Fit Jeans',
    description: 'Classic slim fit jeans in premium Japanese denim. Features subtle fading and comfortable stretch. A wardrobe staple.',
    category: 'lower_body',
    cloth_type: 'Trousers',
    price: 149.00,
    image_1: 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=800&q=80',
    image_2: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=800&q=80',
    image_3: 'https://images.unsplash.com/photo-1604176354204-9268737828e4?w=800&q=80',
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Indigo', 'Black', 'Light Wash'],
    featured: true,
    stock: 80,
  },
  {
    id: '9',
    name: 'Pleated Midi Skirt',
    description: 'Elegant pleated midi skirt in flowing satin fabric. Features knife pleats and comfortable elasticated waist.',
    category: 'lower_body',
    cloth_type: 'Trousers',
    price: 129.00,
    image_1: 'https://images.unsplash.com/photo-1583496661160-fb5886a0uj0f?w=800&q=80',
    image_2: 'https://images.unsplash.com/photo-1592301933927-35b597393c0a?w=800&q=80',
    image_3: 'https://images.unsplash.com/photo-1577900232427-18219b9166a0?w=800&q=80',
    sizes: ['XS', 'S', 'M', 'L'],
    colors: ['Black', 'Navy', 'Emerald'],
    featured: false,
    stock: 40,
  },
  {
    id: '10',
    name: 'Leather Straight Leg Pants',
    description: 'Sleek leather straight leg pants in butter-soft lambskin. Features clean lines and concealed side zip. Sophisticated edge.',
    category: 'lower_body',
    cloth_type: 'Trousers',
    price: 399.00,
    image_1: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&q=80',
    image_2: 'https://images.unsplash.com/photo-1506629082955-511b1aa562c8?w=800&q=80',
    image_3: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=800&q=80',
    sizes: ['XS', 'S', 'M', 'L'],
    colors: ['Black', 'Burgundy'],
    featured: true,
    stock: 20,
  },
  {
    id: '11',
    name: 'Silk Slip Dress',
    description: 'Elegant silk slip dress with delicate spaghetti straps. Features a subtle cowl neckline and flattering bias cut.',
    category: 'dresses',
    cloth_type: 'Dresses',
    price: 279.00,
    image_1: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=800&q=80',
    image_2: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=800&q=80',
    image_3: 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=800&q=80',
    sizes: ['XS', 'S', 'M', 'L'],
    colors: ['Champagne', 'Black', 'Blush'],
    featured: true,
    stock: 30,
  },
  {
    id: '12',
    name: 'Cocktail Midi Dress',
    description: 'Structured cocktail dress with fit-and-flare silhouette. Features elegant boat neckline and hidden back zip.',
    category: 'dresses',
    cloth_type: 'Dresses',
    price: 329.00,
    image_1: 'https://images.unsplash.com/photo-1562137369-1a1a0bc66744?w=800&q=80',
    image_2: 'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=800&q=80',
    image_3: 'https://images.unsplash.com/photo-1496217590455-aa63a8350eea?w=800&q=80',
    sizes: ['XS', 'S', 'M', 'L'],
    colors: ['Black', 'Navy', 'Ruby'],
    featured: true,
    stock: 25,
  },
  {
    id: '13',
    name: 'Wrap Maxi Dress',
    description: 'Flowing wrap maxi dress in lightweight viscose. Features adjustable tie waist and flattering V-neckline.',
    category: 'dresses',
    cloth_type: 'Dresses',
    price: 199.00,
    image_1: 'https://images.unsplash.com/photo-1539008835657-9e8e9680c956?w=800&q=80',
    image_2: 'https://images.unsplash.com/photo-1572804013427-4d7ca7268217?w=800&q=80',
    image_3: 'https://images.unsplash.com/photo-1518622358385-8ea7d0794bf6?w=800&q=80',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Emerald', 'Burgundy', 'Black'],
    featured: false,
    stock: 35,
  },
  {
    id: '14',
    name: 'Lace Evening Gown',
    description: 'Stunning lace evening gown with illusion neckline. Features intricate floral lace and elegant train.',
    category: 'dresses',
    cloth_type: 'Dresses',
    price: 599.00,
    image_1: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=800&q=80',
    image_2: 'https://images.unsplash.com/photo-1518622358385-8ea7d0794bf6?w=800&q=80',
    image_3: 'https://images.unsplash.com/photo-1562137369-1a1a0bc66744?w=800&q=80',
    sizes: ['XS', 'S', 'M', 'L'],
    colors: ['Ivory', 'Black', 'Dusty Rose'],
    featured: true,
    stock: 15,
  },
  {
    id: '15',
    name: 'Midi Shirt Dress',
    description: 'Classic shirt dress in crisp cotton poplin. Features belted waist and button-through front. Versatile elegance.',
    category: 'dresses',
    cloth_type: 'Dresses',
    price: 179.00,
    image_1: 'https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?w=800&q=80',
    image_2: 'https://images.unsplash.com/photo-1591369822096-ffd140ec948f?w=800&q=80',
    image_3: 'https://images.unsplash.com/photo-1562157873-818bc0726f68?w=800&q=80',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['White', 'Navy', 'Black'],
    featured: false,
    stock: 45,
  },
]

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const category = searchParams.get('category')
  const clothType = searchParams.get('cloth_type')
  const featured = searchParams.get('featured')
  const id = searchParams.get('id')

  try {
    // Check if Supabase is configured
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const isSupabaseConfigured = supabaseUrl && !supabaseUrl.includes('your-supabase')

    if (!isSupabaseConfigured) {
      // Return mock data
      let filteredProducts = [...mockProducts]
      
      if (id) {
        const product = filteredProducts.find(p => p.id === id)
        return NextResponse.json(product || null)
      }
      
      // Filter by cloth_type (for page classification) - case insensitive
      if (clothType) {
        filteredProducts = filteredProducts.filter(p => p.cloth_type.toLowerCase() === clothType.toLowerCase())
      } else if (category && category !== 'all') {
        // Fallback to category filter for backward compatibility
        filteredProducts = filteredProducts.filter(p => p.category === category)
      }
      
      if (featured === 'true') {
        filteredProducts = filteredProducts.filter(p => p.featured)
      }

      return NextResponse.json(filteredProducts)
    }

    // Use Supabase if configured
    const { createClient } = await import('@supabase/supabase-js')
    const supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
    )

    if (id) {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('id', id)
        .single()

      if (error) throw error
      return NextResponse.json(data)
    }

    let query = supabase.from('products').select('*')

    // Filter by cloth_type (for page classification) - case insensitive
    if (clothType) {
      query = query.ilike('cloth_type', clothType)
    } else if (category && category !== 'all') {
      // Fallback to category filter for backward compatibility
      query = query.eq('category', category)
    }

    if (featured === 'true') {
      query = query.eq('featured', true)
    }

    const { data, error } = await query.order('created_at', { ascending: false })

    if (error) throw error
    return NextResponse.json(data)
  } catch (error) {
    console.error('Products API error:', error)
    // Fallback to mock data on error
    let filteredProducts = [...mockProducts]
    
    if (id) {
      const product = filteredProducts.find(p => p.id === id)
      return NextResponse.json(product || null)
    }
    
    // Filter by cloth_type (for page classification) - case insensitive
    if (clothType) {
      filteredProducts = filteredProducts.filter(p => p.cloth_type.toLowerCase() === clothType.toLowerCase())
    } else if (category && category !== 'all') {
      // Fallback to category filter for backward compatibility
      filteredProducts = filteredProducts.filter(p => p.category === category)
    }
    
    if (featured === 'true') {
      filteredProducts = filteredProducts.filter(p => p.featured)
    }

    return NextResponse.json(filteredProducts)
  }
}
