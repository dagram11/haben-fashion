import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "VTON - Virtual Try-On Fashion",
  description: "Experience fashion like never before with AI-powered virtual try-on technology. See how clothes look on you before you buy.",
  keywords: ["Virtual Try-On", "Fashion", "AI", "E-commerce", "Clothes", "Shopping"],
  authors: [{ name: "VTON Team" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "VTON - Virtual Try-On Fashion",
    description: "Experience fashion like never before with AI-powered virtual try-on technology.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-zinc-950 text-white`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
