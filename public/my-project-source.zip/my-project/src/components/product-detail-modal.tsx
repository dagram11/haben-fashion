'use client'

import { useState } from 'react'
import { X, Heart, ShoppingBag, Camera, ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useCartStore } from '@/store/cart'
import { cn } from '@/lib/utils'

interface Product {
  id: string
  name: string
  description: string
  category: string
  price: number
  image_1: string
  image_2?: string
  image_3?: string
  sizes: string[]
  colors: string[]
  stock?: number
}

interface ProductDetailModalProps {
  product: Product | null
  isOpen: boolean
  onClose: () => void
  onTryOn?: (product: Product) => void
}

export function ProductDetailModal({ product, isOpen, onClose, onTryOn }: ProductDetailModalProps) {
  const [selectedSize, setSelectedSize] = useState<string>('')
  const [selectedColor, setSelectedColor] = useState<string>('')
  const [currentImage, setCurrentImage] = useState(0)
  const [isLiked, setIsLiked] = useState(false)
  
  const addItem = useCartStore((state) => state.addItem)
  const openCart = useCartStore((state) => state.openCart)

  if (!isOpen || !product) return null

  const images = [product.image_1, product.image_2, product.image_3].filter(Boolean)
  const categoryLabel = product.category.replace('_', ' ')

  const handleAddToCart = () => {
    if (!selectedSize) return
    addItem({
      productId: product.id,
      name: product.name,
      price: product.price,
      image: product.image_1,
      size: selectedSize,
      color: selectedColor || product.colors[0] || 'Default',
    })
    openCart()
  }

  const handleTryOn = () => {
    if (onTryOn) {
      onTryOn(product)
    }
  }

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />

      {/* Modal */}
      <div className="relative z-10 w-full max-w-5xl mx-4 bg-zinc-900 rounded-2xl border border-zinc-800 shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid md:grid-cols-2 gap-0">
          {/* Images */}
          <div className="relative bg-zinc-800">
            <div className="aspect-[3/4] relative">
              <img
                src={images[currentImage]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
              
              {/* Image Navigation */}
              {images.length > 1 && (
                <>
                  <button
                    onClick={() => setCurrentImage((prev) => (prev > 0 ? prev - 1 : images.length - 1))}
                    className="absolute left-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => setCurrentImage((prev) => (prev < images.length - 1 ? prev + 1 : 0))}
                    className="absolute right-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </>
              )}
            </div>

            {/* Thumbnails */}
            {images.length > 1 && (
              <div className="flex gap-2 p-4">
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentImage(idx)}
                    className={cn(
                      'w-16 h-20 rounded-lg overflow-hidden border-2 transition-colors',
                      currentImage === idx ? 'border-white' : 'border-transparent'
                    )}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Details */}
          <div className="p-8">
            {/* Category */}
            <p className="text-xs text-zinc-400 uppercase tracking-widest mb-2">
              {categoryLabel}
            </p>

            {/* Title & Price */}
            <div className="flex items-start justify-between mb-4">
              <h1 className="text-3xl font-bold">{product.name}</h1>
              <button
                onClick={() => setIsLiked(!isLiked)}
                className={cn(
                  'p-2 rounded-full transition-all',
                  isLiked ? 'text-red-500' : 'text-zinc-400 hover:text-white'
                )}
              >
                <Heart className={cn('w-6 h-6', isLiked && 'fill-current')} />
              </button>
            </div>

            <p className="text-2xl font-semibold mb-6">${product.price.toFixed(2)}</p>

            {/* Description */}
            <p className="text-zinc-400 leading-relaxed mb-8">{product.description}</p>

            {/* Color Selection */}
            {product.colors && product.colors.length > 0 && (
              <div className="mb-6">
                <p className="text-sm text-zinc-400 mb-3">
                  Color: <span className="text-white">{selectedColor || 'Select'}</span>
                </p>
                <div className="flex gap-2">
                  {product.colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={cn(
                        'px-4 py-2 rounded-xl text-sm font-medium transition-all',
                        selectedColor === color
                          ? 'bg-white text-black'
                          : 'bg-zinc-800 text-white hover:bg-zinc-700'
                      )}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Size Selection */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-3">
                <p className="text-sm text-zinc-400">
                  Size: <span className="text-white">{selectedSize || 'Select'}</span>
                </p>
                <button className="text-sm text-zinc-400 hover:text-white underline">
                  Size Guide
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={cn(
                      'w-14 h-12 rounded-xl text-sm font-medium transition-all',
                      selectedSize === size
                        ? 'bg-white text-black'
                        : 'bg-zinc-800 text-white hover:bg-zinc-700'
                    )}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-3">
              {/* Try On Button */}
              <Button
                onClick={handleTryOn}
                variant="outline"
                className="w-full rounded-xl py-6 border-zinc-600 hover:bg-zinc-800"
              >
                <Camera className="w-5 h-5 mr-2" />
                Try Online
              </Button>

              {/* Add to Cart */}
              <Button
                onClick={handleAddToCart}
                disabled={!selectedSize}
                className="w-full rounded-xl py-6 bg-white text-black hover:bg-zinc-200 text-lg font-medium"
              >
                <ShoppingBag className="w-5 h-5 mr-2" />
                Add to Bag
              </Button>
            </div>

            {/* Stock Info */}
            {product.stock && (
              <p className="text-center text-sm text-zinc-400 mt-4">
                {product.stock > 10 ? 'In Stock' : `Only ${product.stock} left`}
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
