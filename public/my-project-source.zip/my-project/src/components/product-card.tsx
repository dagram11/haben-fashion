'use client'

import { useState } from 'react'
import { Heart, ShoppingBag, Camera } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useCartStore } from '@/store/cart'
import { cn } from '@/lib/utils'

interface Product {
  id: string
  name: string
  description: string
  category: string
  price: number
  image_1: string
  image_2?: string
  image_3?: string
  sizes: string[]
  colors: string[]
  featured?: boolean
}

interface ProductCardProps {
  product: Product
  onViewDetails: (product: Product) => void
}

export function ProductCard({ product, onViewDetails }: ProductCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const [isLiked, setIsLiked] = useState(false)
  const addItem = useCartStore((state) => state.addItem)
  const openCart = useCartStore((state) => state.openCart)

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation()
    addItem({
      productId: product.id,
      name: product.name,
      price: product.price,
      image: product.image_1,
      size: product.sizes[2] || 'M',
      color: product.colors[0] || 'Black',
    })
    openCart()
  }

  return (
    <div
      className="group cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={() => onViewDetails(product)}
    >
      {/* Image Container */}
      <div className="relative aspect-[3/4] rounded-2xl overflow-hidden bg-zinc-800 mb-4">
        <img
          src={product.image_1}
          alt={product.name}
          className={cn(
            'w-full h-full object-cover transition-transform duration-700',
            isHovered && 'scale-105'
          )}
        />
        
        {/* Overlay */}
        <div
          className={cn(
            'absolute inset-0 bg-black/20 transition-opacity duration-300',
            isHovered ? 'opacity-100' : 'opacity-0'
          )}
        />

        {/* Actions */}
        <div
          className={cn(
            'absolute bottom-4 left-4 right-4 flex gap-2 transition-all duration-300',
            isHovered ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
          )}
        >
          <Button
            onClick={handleQuickAdd}
            className="flex-1 bg-white text-black hover:bg-zinc-200 rounded-xl"
          >
            <ShoppingBag className="w-4 h-4 mr-2" />
            Add to Bag
          </Button>
        </div>

        {/* Like Button */}
        <button
          onClick={(e) => {
            e.stopPropagation()
            setIsLiked(!isLiked)
          }}
          className={cn(
            'absolute top-4 right-4 p-2 rounded-full transition-all',
            isLiked ? 'bg-red-500 text-white' : 'bg-black/50 text-white hover:bg-black/70'
          )}
        >
          <Heart className={cn('w-4 h-4', isLiked && 'fill-current')} />
        </button>

        {/* Featured Badge */}
        {product.featured && (
          <div className="absolute top-4 left-4 px-3 py-1 bg-white text-black text-xs font-medium rounded-full">
            Featured
          </div>
        )}
      </div>

      {/* Info */}
      <div className="space-y-1">
        <p className="text-xs text-zinc-400 uppercase tracking-wider">
          {product.category.replace('_', ' ')}
        </p>
        <h3 className="font-medium text-white group-hover:text-zinc-200 transition-colors">
          {product.name}
        </h3>
        <p className="text-lg font-semibold">${product.price.toFixed(2)}</p>
      </div>
    </div>
  )
}
