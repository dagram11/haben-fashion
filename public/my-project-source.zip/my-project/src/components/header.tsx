'use client'

import { useState, useEffect, useSyncExternalStore } from 'react'
import Link from 'next/link'
import { ShoppingBag, Menu, X, Search } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useCartStore } from '@/store/cart'
import { cn } from '@/lib/utils'

const categories = [
  { name: 'All', filter: 'all', href: '/' },
  { name: 'Hoodies', filter: 'Hoodies', href: '/upper' },
  { name: 'Trousers', filter: 'Trousers', href: '/lower' },
  { name: 'Dresses', filter: 'Dresses', href: '/dresses' },
]

// Helper for hydration-safe client-side only rendering
const emptySubscribe = () => () => {}
const getSnapshot = () => true
const getServerSnapshot = () => false

interface HeaderProps {
  currentCategory?: string
  onCategoryChange?: (category: string) => void
  showFilters?: boolean
}

export function Header({ currentCategory = 'all', onCategoryChange, showFilters = true }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const isMounted = useSyncExternalStore(emptySubscribe, getSnapshot, getServerSnapshot)
  const itemCount = useCartStore((state) => state.getItemCount())
  const openCart = useCartStore((state) => state.openCart)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const showCartCount = isMounted && itemCount > 0

  return (
    <header
      className={cn(
        'fixed top-0 left-0 right-0 z-30 transition-all duration-300',
        isScrolled
          ? 'bg-zinc-900/95 backdrop-blur-md border-b border-zinc-800'
          : 'bg-transparent'
      )}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
              <span className="text-black font-bold text-lg">V</span>
            </div>
            <span className="text-xl font-bold tracking-tight">VTON</span>
          </Link>

          {/* Desktop Navigation */}
          {showFilters && (
            <nav className="hidden lg:flex items-center gap-8">
              {categories.map((cat) => (
                <Link
                  key={cat.filter}
                  href={cat.href}
                  className={cn(
                    'text-sm font-medium transition-colors relative py-2',
                    currentCategory === cat.filter
                      ? 'text-white'
                      : 'text-zinc-400 hover:text-white'
                  )}
                >
                  {cat.name}
                  {currentCategory === cat.filter && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-white rounded-full" />
                  )}
                </Link>
              ))}
            </nav>
          )}

          {/* Right Actions */}
          <div className="flex items-center gap-4">
            <button
              className="p-2 hover:bg-zinc-800 rounded-full transition-colors"
              aria-label="Search"
            >
              <Search className="w-5 h-5" />
            </button>
            
            <button
              onClick={openCart}
              className="relative p-2 hover:bg-zinc-800 rounded-full transition-colors"
              aria-label="Cart"
            >
              <ShoppingBag className="w-5 h-5" />
              {showCartCount && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-white text-black text-xs font-bold rounded-full flex items-center justify-center">
                  {itemCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 hover:bg-zinc-800 rounded-full transition-colors"
            >
              {isMobileMenuOpen ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && showFilters && (
          <div className="lg:hidden py-4 border-t border-zinc-800 bg-zinc-950/98 backdrop-blur-md absolute left-0 right-0 top-full shadow-2xl">
            <nav className="flex flex-col gap-2 px-4">
              {categories.map((cat) => (
                <Link
                  key={cat.filter}
                  href={cat.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={cn(
                    'px-4 py-3 rounded-xl text-left text-sm font-medium transition-colors',
                    currentCategory === cat.filter
                      ? 'bg-zinc-800 text-white'
                      : 'text-zinc-400 hover:bg-zinc-800/50 hover:text-white'
                  )}
                >
                  {cat.name}
                </Link>
              ))}
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
