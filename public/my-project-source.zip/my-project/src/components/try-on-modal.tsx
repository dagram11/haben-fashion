'use client'

import { useState, useCallback } from 'react'
import { X, Upload, Download, Camera, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface TryOnModalProps {
  productId: string
  productName: string
  productImage: string
  productDescription: string
  productCategory: string
  sizes: string[]
  onClose: () => void
}

type Status = 'upload' | 'select-size' | 'processing' | 'completed' | 'error'

export function TryOnModal({
  productId,
  productName,
  productImage,
  productDescription,
  productCategory,
  sizes,
  onClose,
}: TryOnModalProps) {
  const [status, setStatus] = useState<Status>('upload')
  const [userImage, setUserImage] = useState<string>('')
  const [selectedSize, setSelectedSize] = useState<string>('')
  const [resultImage, setResultImage] = useState<string>('')
  const [tryonId, setTryonId] = useState<string>('')
  const [error, setError] = useState<string>('')
  const [isDragging, setIsDragging] = useState(false)
  const [isDownloading, setIsDownloading] = useState(false)

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    const file = e.dataTransfer.files[0]
    if (file && file.type.startsWith('image/')) {
      processImage(file)
    }
  }, [])

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      processImage(file)
    }
  }, [])

  const processImage = (file: File) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      const base64 = e.target?.result as string
      setUserImage(base64)
      setSelectedSize('')
      setStatus('select-size')
    }
    reader.readAsDataURL(file)
  }

  const handleTryOn = async () => {
    if (!userImage || !selectedSize) {
      return
    }

    setStatus('processing')
    setError('')

    try {
      // Skip IP location - it's causing 502 errors and is optional
      const ipData = { ip: '', country: '', city: '' }

      const response = await fetch('/api/tryon', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId,
          userImage,
          size: selectedSize,
          ip: ipData.ip,
          country: ipData.country,
          city: ipData.city,
          productImage,
          productDescription,
          productCategory,
        }),
      })

      // Handle non-JSON responses
      const contentType = response.headers.get('content-type')
      if (!contentType || !contentType.includes('application/json')) {
        const text = await response.text()
        throw new Error(`Server error: ${response.status} ${response.statusText}`)
      }

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data?.error || `Server error (${response.status})`)
      }
      
      if (!data.preview) {
        throw new Error('No preview image received from server')
      }
      
      setTryonId(data.tryonId || `tryon-${Date.now()}`)
      setResultImage(data.preview)
      setStatus('completed')
      
    } catch (err) {
      console.error('Try-on error:', err)
      const errorMessage = err instanceof Error ? err.message : 'An error occurred'
      setError(errorMessage)
      setStatus('error')
    }
  }

  const handleDownload = async () => {
    if (!tryonId || !productName || !resultImage || isDownloading) return

    setIsDownloading(true)
    try {
      const response = await fetch('/api/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tryonId,
          productName,
          imageBase64: resultImage,
        }),
      })

      if (!response.ok) throw new Error('Download failed')

      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `${productName.replace(/\s+/g, '-').toLowerCase()}.png`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      a.remove()
    } catch (err) {
      console.error('Download error:', err)
      setError('Failed to download image')
    } finally {
      setIsDownloading(false)
    }
  }

  const handleReset = () => {
    setUserImage('')
    setSelectedSize('')
    setResultImage('')
    setTryonId('')
    setError('')
    setStatus('upload')
  }

  const handleClose = () => {
    handleReset()
    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={handleClose}
      />

      <div className="relative z-10 w-full max-w-2xl mx-4 bg-zinc-900 rounded-2xl border border-zinc-800 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-zinc-800">
          <div>
            <h2 className="text-2xl font-bold text-white">Virtual Try-On</h2>
            <p className="text-zinc-400 mt-1">{productName}</p>
          </div>
          <button
            onClick={handleClose}
            className="p-2 rounded-full hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5 text-zinc-400" />
          </button>
        </div>

        <div className="p-6 max-h-[70vh] overflow-y-auto">
          
          {status === 'upload' && (
            <div
              className={cn(
                'border-2 border-dashed rounded-xl p-12 text-center transition-all cursor-pointer',
                isDragging
                  ? 'border-white bg-zinc-800'
                  : 'border-zinc-700 hover:border-zinc-600'
              )}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => document.getElementById('file-input')?.click()}
            >
              <input
                type="file"
                id="file-input"
                className="hidden"
                accept="image/*"
                onChange={handleFileSelect}
              />
              <div className="flex flex-col items-center gap-4">
                <div className="p-4 bg-zinc-800 rounded-full">
                  <Camera className="w-8 h-8 text-white" />
                </div>
                <div>
                  <p className="text-lg font-medium text-white">
                    Drag your image here
                  </p>
                  <p className="text-zinc-400 mt-1">or click to browse</p>
                </div>
                <Button variant="outline" className="mt-2 rounded-full">
                  <Upload className="w-4 h-4 mr-2" />
                  Browse Files
                </Button>
              </div>
            </div>
          )}

          {status === 'select-size' && (
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="flex-1">
                  <p className="text-sm text-zinc-400 mb-2">Your Photo</p>
                  <div className="aspect-[3/4] rounded-xl overflow-hidden bg-zinc-800">
                    <img
                      src={userImage}
                      alt="User"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
                <div className="flex-1">
                  <p className="text-sm text-zinc-400 mb-2">Product</p>
                  <div className="aspect-[3/4] rounded-xl overflow-hidden bg-zinc-800">
                    <img
                      src={productImage}
                      alt={productName}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              </div>

              <div>
                <p className="text-sm text-zinc-400 mb-3">Select Size</p>
                <div className="flex flex-wrap gap-2">
                  {sizes.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={cn(
                        'px-6 py-3 rounded-xl font-medium transition-all',
                        selectedSize === size
                          ? 'bg-white text-black'
                          : 'bg-zinc-800 text-white hover:bg-zinc-700'
                      )}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => {
                    setUserImage('')
                    setStatus('upload')
                  }}
                  className="flex-1 rounded-xl"
                >
                  Change Photo
                </Button>
                <Button
                  onClick={handleTryOn}
                  disabled={!selectedSize}
                  className="flex-1 rounded-xl bg-white text-black hover:bg-zinc-200"
                >
                  Generate Try-On
                </Button>
              </div>
            </div>
          )}

          {status === 'processing' && (
            <div className="py-16 text-center">
              <div className="flex justify-center mb-6">
                <div className="relative w-20 h-20">
                  <div className="absolute inset-0 border-4 border-zinc-700 rounded-full" />
                  <div className="absolute inset-0 border-4 border-white border-t-transparent rounded-full animate-spin" />
                </div>
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">
                Generating Your Try-On
              </h3>
              <p className="text-zinc-400">
                This may take 30-60 seconds...
              </p>
            </div>
          )}

          {status === 'error' && (
            <div className="py-12 text-center">
              <div className="p-4 bg-red-500/10 rounded-full w-fit mx-auto mb-4">
                <X className="w-8 h-8 text-red-500" />
              </div>
              <p className="text-red-400 mb-4">{error || 'An error occurred'}</p>
              <Button
                onClick={handleReset}
                className="rounded-xl bg-white text-black"
              >
                Try Again
              </Button>
            </div>
          )}

          {status === 'completed' && resultImage && (
            <div className="space-y-6">
              <div className="aspect-[3/4] rounded-xl overflow-hidden bg-zinc-800 mx-auto max-w-sm">
                <img
                  src={`data:image/png;base64,${resultImage}`}
                  alt="Try-on result"
                  className="w-full h-full object-cover"
                />
              </div>
              
              <div className="flex items-center justify-center gap-2 text-green-400">
                <Check className="w-5 h-5" />
                <span>Try-on generated successfully!</span>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={handleReset}
                  disabled={isDownloading}
                  className="flex-1 rounded-xl"
                >
                  Try Another
                </Button>
                <Button
                  onClick={handleDownload}
                  disabled={isDownloading}
                  className="flex-1 rounded-xl bg-white text-black hover:bg-zinc-200"
                >
                  {isDownloading ? (
                    <>
                      <div className="w-4 h-4 mr-2 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                      Preparing download...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4 mr-2" />
                      Download Free
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
