'use client'

import { useCartStore } from '@/store/cart'
import { X, Plus, Minus, ShoppingBag, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { cn } from '@/lib/utils'
import Image from 'next/image'

export function CartDrawer() {
  const { items, isOpen, closeCart, removeItem, updateQuantity, getTotal, clearCart } =
    useCartStore()

  const total = getTotal()

  return (
    <>
      {/* Backdrop */}
      <div
        className={cn(
          'fixed inset-0 z-40 bg-black/80 backdrop-blur-sm transition-opacity',
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        )}
        onClick={closeCart}
      />

      {/* Drawer */}
      <div
        className={cn(
          'fixed right-0 top-0 z-50 h-full w-full max-w-md bg-zinc-900 border-l border-zinc-800 shadow-2xl transition-transform duration-300',
          isOpen ? 'translate-x-0' : 'translate-x-full'
        )}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <ShoppingBag className="w-5 h-5" />
            <h2 className="text-lg font-semibold">Shopping Bag</h2>
            <span className="text-zinc-400">({items.length})</span>
          </div>
          <button
            onClick={closeCart}
            className="p-2 rounded-full hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto p-6 h-[calc(100vh-280px)]">
          {items.length === 0 ? (
            <div className="text-center py-12">
              <ShoppingBag className="w-12 h-12 mx-auto text-zinc-600 mb-4" />
              <p className="text-zinc-400">Your bag is empty</p>
            </div>
          ) : (
            <div className="space-y-6">
              {items.map((item) => (
                <div key={`${item.productId}-${item.size}-${item.color}`} className="flex gap-4">
                  <div className="w-24 h-32 rounded-lg overflow-hidden bg-zinc-800 flex-shrink-0">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium truncate">{item.name}</h3>
                    <p className="text-sm text-zinc-400 mt-1">
                      {item.size} / {item.color}
                    </p>
                    <p className="text-sm font-medium mt-1">${item.price.toFixed(2)}</p>
                    
                    <div className="flex items-center gap-3 mt-3">
                      <div className="flex items-center border border-zinc-700 rounded-full">
                        <button
                          onClick={() =>
                            updateQuantity(
                              item.productId,
                              item.size,
                              item.color,
                              Math.max(1, item.quantity - 1)
                            )
                          }
                          className="p-2 hover:bg-zinc-800 rounded-l-full"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-8 text-center text-sm">{item.quantity}</span>
                        <button
                          onClick={() =>
                            updateQuantity(
                              item.productId,
                              item.size,
                              item.color,
                              item.quantity + 1
                            )
                          }
                          className="p-2 hover:bg-zinc-800 rounded-r-full"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                      <button
                        onClick={() => removeItem(item.productId, item.size, item.color)}
                        className="p-2 hover:bg-zinc-800 rounded-full text-zinc-400 hover:text-white"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        {items.length > 0 && (
          <div className="absolute bottom-0 left-0 right-0 p-6 bg-zinc-900 border-t border-zinc-800">
            <div className="flex items-center justify-between mb-4">
              <span className="text-zinc-400">Subtotal</span>
              <span className="text-xl font-semibold">${total.toFixed(2)}</span>
            </div>
            <Button
              className="w-full rounded-xl bg-white text-black hover:bg-zinc-200 py-6 text-lg font-medium"
              onClick={() => {
                closeCart()
                window.location.href = '/?checkout=true'
              }}
            >
              Checkout
            </Button>
            <button
              onClick={clearCart}
              className="w-full text-center text-sm text-zinc-400 hover:text-white mt-3 py-2"
            >
              Clear Bag
            </button>
          </div>
        )}
      </div>
    </>
  )
}
